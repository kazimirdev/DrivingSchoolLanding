
Images
======

Place your images inside the `images` folder and match the filenames used in
`index.html` (e.g. hero.jpg, lesson1.jpg, lesson2.jpg, plac1.jpg, plac2.jpg,
auto1.jpg). You can replace or add slides by editing the HTML.
